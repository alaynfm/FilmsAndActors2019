import java.util.LinkedList;
import java.util.Queue;

public class RedOrdenadors {

    protected Boolean[][] adjMatrix; // adjacency matrix

    private class Posicion{
        int fila;
        int columna;

        public Posicion(int filaa,int posicion){
            fila = filaa;
            columna = posicion;
        }
    }

    public int[] obtenerCostes() {

        //Posicion pos = new Posicion(0,0);
        int i = 0;
        int f = 0;
        boolean[][] visitados = new boolean[10][10];
        boolean enc = false;
        int[][]coste = new int[0][0];

        for(int a = 0; a < adjMatrix.length; a++){
            for(int j= 0; j< adjMatrix[0].length;j++){
                coste[a][j] = coste(i,j);
            }
        }

    return null;
    }// M�todo a desarrollar

    public int coste(int a,int j){
    return 0;
    }
}
