package partidaCartas;

public class Bicola {
}
