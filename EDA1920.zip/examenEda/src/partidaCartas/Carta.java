package partidaCartas;

public class Carta {
}
