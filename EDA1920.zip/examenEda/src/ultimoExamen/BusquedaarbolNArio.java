package ultimoExamen;

public class BusquedaarbolNArio {

    public class BinaryTreeNode<T> {
        T[] valores;
        BinaryTreeNode<T>[] hijos;
        // el tama�o es de la tabla de valores + 1
    }

    BinaryTreeNode<Integer> root;


    public boolean estaRecursivo(Integer elem){
        // post: el resultado es true si �elem� est� en el �rbol y false si no;
        return estaRecursivo(elem,root);
    }//fin programa recursivo1

    public boolean estaRecursivo(Integer elem, BinaryTreeNode a){
        boolean enc = false;
        int posicion = -1;
        if(a!=null) {
            for (int i = 0; i < a.valores.length; i++) {
                if(elem > (Integer) a.valores[i]){
                    posicion = i;
                    break;
                }
                else if (elem.equals(a.valores[i])){
                    enc = true;
                    break;
                }
            }
            if(enc)return true;
            else //Queda ver si tiene hijos
                if(a.hijos[posicion] == null) return false;         //No tiene mas hijos, acabamos el programa
                else return estaRecursivo(elem,a.hijos[posicion]);  //Tiene mas hijos, seguimos con el programa

        }else return false;
    }//fin programa recursivo2

    public boolean estaIterativa(Integer elem){
        return estaIterativa(elem,root);

    }//fin programa iterativo1
    public boolean estaIterativa(Integer elem, BinaryTreeNode a){
        boolean find = false;
        boolean ext = false;
        BinaryTreeNode act = a;
        int posicion = -1;
        while(!ext){
            for (int i= 0 ; i<act.hijos.length;i++){
                if(elem > (Integer) act.valores[i]){
                    posicion = i;
                    break;
                }
                else if (elem.equals(a.valores[i])){
                    find = true;
                    break;
                }
            }
            if(find)ext = true;
            else {                                                      //Queda ver si tiene hijos
                if (act.hijos[posicion] == null) ext = true;            //No tiene mas hijos, acabamos el programa
                else act = act.hijos[posicion];                        //Tiene mas hijos, seguimos con el programa
            }
        }
        if(find)return true;
        else return false;
    }//fin programa iterativo2
}