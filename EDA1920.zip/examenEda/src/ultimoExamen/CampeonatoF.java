package ultimoExamen;

public class CampeonatoF {

    public class Marcador {
        String ganador; // nombre del equipo
        Integer golesIzq;
        Integer golesDer;
    }
    public class Nodo {
        Marcador info;
        Nodo izq, der;
    }

        private Nodo root;

        public String campeon(){
            //Vamos a recorrer el grago por niveles POSTORDEN
            campeon(root);
            return root.info.ganador;
        }
        public void campeon(Nodo a){
            if(a==null) return;
            campeon(a.izq);
            campeon(a.der);
            //miramos cual ponemos
            if(a.info.ganador==null){
                if(a.info.golesDer>a.info.golesIzq) a.info.ganador = a.der.info.ganador;
                else a.info.ganador = a.izq.info.ganador;
            }
        }

    public CampeonatoF(){
        Marcador m1 = new Marcador();
        m1.ganador = "Athletic";
        m1.golesIzq = -1;
        m1.golesDer = -1;

        Marcador m2 = new Marcador();
        m2.ganador = "Real Mandril";
        m2.golesDer = -1;
        m2.golesIzq = -1;

        Marcador m3 = new Marcador();
        m3.ganador = null;
        m3.golesDer = 20;
        m3.golesIzq = 1;

        Nodo principal = new Nodo();
        principal.info = m3;

        Nodo n1 = new Nodo();
        n1.info = m1;

        Nodo n2 = new Nodo();
        n2.info = m2;

        principal.der = n1;
        principal.izq = n2;
        root = principal;
    }
    public static void main(String[] args) {
        // TODO Auto-generated method stub
        CampeonatoF camp = new CampeonatoF();
        System.out.println(camp.campeon());
    }
}
