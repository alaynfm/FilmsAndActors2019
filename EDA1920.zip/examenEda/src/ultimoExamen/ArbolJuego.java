package ultimoExamen;

import java.util.HashMap;

public class ArbolJuego {

    private Nodo root;

    public ArbolJuego() {
        Nodo n1 = new Nodo(new Info("B", 3));
        Nodo n2 = new Nodo(new Info("C", 3));
        Nodo n3 = new Nodo(new Info("D", 3));
        Nodo n4 = new Nodo(new Info("E", 3));
        Nodo n5 = new Nodo(new Info("F", 3));
        Nodo n6 = new Nodo(new Info("G", 3));
        Nodo n7 = new Nodo(new Info("H", 3));

        root = n1;
        n1.izq = n2;
        n2.padre = n1;
        n1.der = n3;
        n3.padre = n1;
        n2.izq = n4;
        n4.padre = n2;
        n2.der = n5;
        n5.padre = n2;
        n3.izq = n6;
        n6.padre = n3;
        n3.der = n7;
        n7.padre = n3;
    }

    public void print() {
        print(root);
    }

    private void print(Nodo n) {
        if (n != null) {
            print(n.izq);
            n.content.print();
            print(n.der);
        }
    }

    //Sin utilizar padres
    public void premiarSinPadres(int puntos, String elem) {
        HashMap<String, Nodo> recorrido = new HashMap<String, Nodo>();
        boolean premiado = premiarSinPadres(puntos, elem, root.izq, recorrido, root); //Premiamos al ganador
        if(!premiado) premiarSinPadres(puntos, elem, root.der, recorrido, root);
         //Premiar antecesores
        String n = elem;
        while (puntos > 0 && !n.equals(root.content.s)) { //No vamos a repartir puntos negativos
            recorrido.get(n).content.puntos = recorrido.get(n).content.puntos + (--puntos);
            n = recorrido.get(n).content.s;
        }
    }

    private boolean premiarSinPadres(int puntos, String elem, Nodo a, HashMap<String, Nodo> recorrido, Nodo act) {
        // COMPLETAR
        //Pre: el Arbol no esta vacio
        if (a == null) return false; //"No se ha encontrado"
        else {
            recorrido.put(a.content.s, act);
            act = a;
            if (a.content.s.equals(elem)) {
                a.content.puntos = a.content.puntos + puntos;
                return true;
            } else
                return premiarSinPadres(puntos, elem, a.izq, recorrido, act) || premiarSinPadres(puntos, elem, a.der, recorrido, act);
        }
    }


    private class Info {
        String s;
        Integer puntos;

        public Info(String nom, int p) {
            s = nom;
            puntos = p;
        }

        public void print() {
            System.out.print(" " + s + " " + puntos + ", ");
        }
    }

    private class Nodo {
        Info content;
        Nodo izq, der;
        Nodo padre;

        public Nodo(Info i) {
            content = i;
        }

    }

    public static void main(String[] args) {
        // TODO Auto-generated method stub
        ArbolJuego a = new ArbolJuego();
        a.print();
        System.out.println();
        a.premiarSinPadres(8, "G");
        a.print();
    }

}


