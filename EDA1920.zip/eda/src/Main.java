import primeraFase.Menus;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Menus.getMenu().ejecutarMenu();
	}
}